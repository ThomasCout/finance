---
name: Other
about: All other issues
title: ''
labels: ''
assignees: ''

---

**PLEASE READ before opening an issue:**

- Is this a feature request?  Please [open a feature request discussion](https://github.com/maybe-finance/maybe/discussions/new?category=feature-requests).
- Do you need help or have a question?  Please [open a discussion](https://github.com/maybe-finance/maybe/discussions/new/choose) or [join our Discord](https://link.maybe.co/discord) and post to the "help" channel.

----------------------

**Is this issue related to a problem?  Please describe.**

**Describe the work that needs to be done to address this issue**

**Additional context**
