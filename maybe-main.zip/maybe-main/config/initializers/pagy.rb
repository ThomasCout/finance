require "pagy/extras/overflow"

Pagy::DEFAULT[:overflow] = :last_page
