class Transactions::RulesController < ApplicationController
  layout "with_sidebar"

  def index
  end
end
