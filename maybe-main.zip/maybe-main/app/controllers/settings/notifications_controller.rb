class Settings::NotificationsController < SettingsController
  def edit
  end

  def update
  end
end
