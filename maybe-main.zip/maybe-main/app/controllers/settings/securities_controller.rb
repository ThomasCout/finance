class Settings::SecuritiesController < SettingsController
  def edit
  end

  def update
  end
end
