class SettingsController < ApplicationController
  layout "with_sidebar"
end
