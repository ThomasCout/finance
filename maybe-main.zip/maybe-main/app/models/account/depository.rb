class Account::Depository < ApplicationRecord
  include Accountable
end
