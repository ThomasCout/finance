class Account::Vehicle < ApplicationRecord
  include Accountable
end
