class Account::Property < ApplicationRecord
  include Accountable
end
