class Account::OtherAsset < ApplicationRecord
  include Accountable
end
