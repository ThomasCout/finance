class Account::Loan < ApplicationRecord
  include Accountable
end
