class Account::Credit < ApplicationRecord
  include Accountable
end
