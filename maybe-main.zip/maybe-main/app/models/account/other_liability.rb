class Account::OtherLiability < ApplicationRecord
  include Accountable
end
