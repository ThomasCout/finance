class Account::Crypto < ApplicationRecord
  include Accountable
end
