module Settings::HostingHelper
end
