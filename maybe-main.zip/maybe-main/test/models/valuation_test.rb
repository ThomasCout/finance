require "test_helper"

class ValuationTest < ActiveSupport::TestCase
end
