require "test_helper"

class Account::BalanceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
