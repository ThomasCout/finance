require "test_helper"

class Account::OtherAssetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
