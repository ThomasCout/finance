require "test_helper"

class Account::CryptoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
