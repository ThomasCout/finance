require "test_helper"

class Account::LoanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
