require "test_helper"

class Account::DepositoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
