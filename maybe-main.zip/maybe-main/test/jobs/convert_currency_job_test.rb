require "test_helper"

class ConvertCurrencyJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
