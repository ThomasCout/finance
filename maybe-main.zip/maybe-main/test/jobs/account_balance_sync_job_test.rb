require "test_helper"

class Account::BalanceSyncJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
