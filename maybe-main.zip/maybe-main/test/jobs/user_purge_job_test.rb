require "test_helper"

class UserPurgeJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
