require "test_helper"

class DailyExchangeRateJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
